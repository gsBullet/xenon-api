import { combineReducers } from 'redux';
import tokens from './auth';

export default combineReducers({
  tokens,
});
