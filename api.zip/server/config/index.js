const requireDir = require('../lib/requireDir');

module.exports = requireDir(module, { directory: false });
