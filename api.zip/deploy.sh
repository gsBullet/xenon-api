pm2 stop all
npm run deploy
pm2 logs